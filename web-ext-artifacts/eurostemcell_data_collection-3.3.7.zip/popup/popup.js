document.getElementById('home').href = browser.runtime.getManifest().homepage_url;

async function saveOptions(e){
  e.preventDefault();
  let box = document.getElementById("popup_check");
  if (box.checked) {
    await browser.storage.local.set({hide_popup:box.checked});
  }
  window.close();
}
document.querySelector("form").addEventListener("submit", saveOptions);
document.getElementById('thanks').addEventListener('click',()=>{browser.tabs.create({url:'/src/study_thanks.html'})});
